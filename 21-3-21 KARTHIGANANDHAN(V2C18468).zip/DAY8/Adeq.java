package secweek;

import java.util.*; 
  
public class Adeq { 
    public static void main(String[] args) 
    { 
        ArrayDeque<String> deque 
            = new ArrayDeque<String>(); 
  
        
        // Add at the last 
        deque.add("nandha"); 
  
        // Add at the first 
        deque.addFirst("surya"); 
  
        // Add at the last 
        deque.addLast("david"); 
  
        // Add at the first 
        deque.push("n"); 
  
        // Add at the last 
        deque.offer("new"); 
  
        // Add at the first 
        deque.offerFirst("another"); 
  
        System.out.println(deque + "\n"); 
  
        // We can remove the first element 
        // or the last element.
       
        deque.removeFirst(); 
        deque.removeLast(); 
        System.out.println("Deque after removing "
                           + "first and last: "
                           + deque); 
        
        System.out.println(deque.pop()); 
      //  deque.clear();
        System.out.println("Deque after removing : "+ deque); 
        System.out.println(deque.poll()); //return null only not exception
        System.out.println("Deque after removing : "+ deque); 
        System.out.println(deque.pollFirst()); 
        System.out.println("Deque after removing : "+ deque); 
        System.out.println(deque.pollLast()); 
        System.out.println("Deque after removing : "+ deque); 
    } 
} 