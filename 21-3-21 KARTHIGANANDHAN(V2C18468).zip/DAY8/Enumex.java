package secweek;

import java.util.EnumMap;
 
class Enumex {
 
       enum veg { 
      tomato,potato, cauliflower, ginger //same order
       }
   
    public static void main(String[] args) {
 
        
        EnumMap<veg, Integer> veg1 = new EnumMap<>(veg.class);
        
        veg1.put(veg.cauliflower, 3);
        veg1.put(veg.ginger, 4);
        veg1.put(veg.tomato, 11);
        veg1.put(veg.potato, 2);
        System.out.println("EnumMap veg : " + veg1);
 
        
        System.out.println("Key/Value mappings: " + veg1.entrySet());
 
        
        System.out.println("Keys: " + veg1.keySet());
 
        
        System.out.println("Values: " + veg1.values());
           
          
        System.out.println("Value of tomato : " + veg1.get(veg.tomato));
        
        //remove
       // veg1.clear();//exception
        int value = veg1.remove(veg.tomato);
        System.out.println("Removed Value: " + value);
         
        boolean result = veg1.remove(veg.potato, 2);
        System.out.println("Is the entry removed? " + result);
         
          // print the updated map
        System.out.println("Updated EnumMap: " + veg1);
        
    }
}