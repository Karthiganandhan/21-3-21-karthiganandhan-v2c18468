package secweek;

import java.util.*;
import java.util.Map.Entry; 

public class Linkhm { 
    
    public static void main(String a[]) 
    { 
        
        LinkedHashMap<Integer, Integer> hm 
            = new LinkedHashMap<Integer, Integer>(); 
  
       
        hm.put(2, 1); 
        hm.put(1,2);
        hm.put(1,7);//replace pre key
        hm.put(3,3);
        hm.put(12,22);
  
       
        System.out.println(hm); 
  
        System.out.println("Getting value for key 'one': " + hm.get(1)); 
  
        System.out.println("Size of the map: " + hm.size()); 
  
        System.out.println("Is map empty? " + hm.isEmpty()); 
       // hm.clear();
        System.out.println("Contains key '3'? "+ hm.containsKey(3)); 
  
        //hm.clear();
        
        System.out.println("delete element: "+ hm.remove(3)); //return null if not present
  
       
        System.out.println("Mappings of LinkedHashMap : "+ hm); 
        
        
        LinkedHashMap<Integer, Integer> hm1 = new LinkedHashMap<Integer, Integer>(); 

   
	    hm1.put(21, 1); 
	    hm1.put(13,2);
	    hm1.put(18,7);
	    hm1.put(36,3);
	    hm1.put(19,22);
	    System.out.println("Mappings of LinkedHashMap : "+ hm1); 
	    System.out.println("contains : "+hm1.containsValue(2));
	    System.out.println("equals : "+hm1.equals(hm));
	    hm1.putAll(hm);
	    System.out.println("putall "+ hm1); 
	    hm1.remove(13,2);
	    System.out.println("remove 13,2"+hm1); 
	    hm1.replace(18, 8);
	    System.out.println("last Mappings of LinkedHashMap : "+ hm1); 
	    for(Entry<Integer, Integer> m:hm1.entrySet())  
	    {  
	        System.out.println(m.getKey()+" "+m.getValue());    
	    }
	    
    
        
    } 
}