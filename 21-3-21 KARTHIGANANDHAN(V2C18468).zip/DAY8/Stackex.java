package secweek;

import java.util.ListIterator;
import java.util.Stack;

 
public class Stackex   
{  
public static void main(String[] args)   
{  
Stack<String> stk= new Stack<>();  

stk.push("Apple");  
stk.push("Grapes");  
stk.push("Mango");  
stk.push("Orange");  
System.out.println("Stack: " + stk);  

String fruits = stk.peek();  

System.out.println("Element at top: " + fruits);

String fruitspop = stk.pop();  

System.out.println("Element at pop: " + fruitspop);


System.out.println("after pop Element : " + stk);
System.out.println("Location of mango : " + stk.search("Mango"));  
int x=stk.size();  
System.out.println("The stack size is: "+x); 
System.out.println("is empty:"+stk.isEmpty()); 
System.out.println("The stack capacity is: "+stk.capacity()); 
ListIterator<String> ListIterator = stk.listIterator(stk.size());  
System.out.println("Stack from top to bottom:");  
while (ListIterator.hasNext())   
{  
  
System.out.println( ListIterator.next() );  
}  


Stack<String> stk1= new Stack<>();  


stk1.addAll(stk);  
stk.equals(stk1);
System.out.println("Stack: " + stk1);
if(stk1.contains("Apple"))
{
	stk.removeAll(stk1);
	}

}  
}  