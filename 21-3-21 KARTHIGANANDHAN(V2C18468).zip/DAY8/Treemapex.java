package secweek;

import java.util.Map.Entry;
import java.util.TreeMap;

public class Treemapex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String> tm1= new TreeMap<Integer, String>(); 
		

    
    tm1.put(3, "hi"); 
    tm1.put(2, "this"); 
    tm1.put(1, "is java prg"); 
   // tm1.put(null,"hii");//not allowed

   
    System.out.println(tm1); 
    for(Entry<Integer, String> m:tm1.entrySet())  
    {  
        System.out.println(m.getKey()+" "+m.getValue());    
    }
    
TreeMap<Integer, String> tm2= new TreeMap<Integer, String>(); 
		

    
    tm2.put(3, "hi"); 
    tm2.put(2, "this"); 
    tm2.put(1, "is java prg"); 
   // tm2.put(5, "hlo");
   System.out.println("equal: "+ tm2.equals(tm1));
   System.out.println("tirst key: "+ tm2.firstKey());
   System.out.println("if absent: "+ tm2.putIfAbsent(3, "nandha"));
   System.out.println("descend map: "+ tm2.descendingMap());
   System.out.println("---keyset: "+ tm2.descendingKeySet());
  // tm2.clear();//ret false
   System.out.println("remove: "+ tm2.remove(1,"is java prg"));
   System.out.println(tm2);
   //tm2.clear();//ret null
   System.out.println("pollfirst: "+ tm2.pollFirstEntry());
   System.out.println(tm2);

	}

}
