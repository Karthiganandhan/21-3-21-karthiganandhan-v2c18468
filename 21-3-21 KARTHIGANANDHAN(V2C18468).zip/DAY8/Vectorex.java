package secweek;

import java.util.Enumeration;
import java.util.Vector; 
  
class VectorExample { 
    
    public static void main(String[] args) 
    { 
        
       
  
        
        Vector<Integer> vec = new Vector<Integer>();
  
       
         
            vec.add(1); 
            vec.add(3);
            vec.add(2);
            vec.add(8);
            vec.add(8);
            
		            System.out.println("Index of element is: " +vec.lastIndexOf(8));  
		            System.out.println("size n capacity:"+vec.size()+" "+vec.capacity()); 
		            System.out.println(vec); 
		            vec.remove(3); 
		            System.out.println("after remove :"+vec); 
		            vec.addElement(4);
		            vec.addElement(5);
		           	System.out.println("size n capacity:"+vec.size()+" "+vec.capacity()); 
		           	System.out.println(vec); 
		           //indexof
		           	System.out.println("Index of element is found at: " +vec.indexOf(4, 2)); 
		           	System.out.println("Index of element is found at: " +vec.indexOf(8));  
		           //clone
		           	System.out.println("Cloned vector: "+vec.clone());  
		            Vector<String> vec1 = new Vector<String>(); 
      
           
             
	                vec1.add("nandha"); 
	                vec1.add("surya");
	                vec1.add("david");
	                vec1.add("siva");
      
        System.out.println(vec1); 
  //contains&equal
        System.out.println("Is vector1 equals vector2 ? "+vec.equals(vec1));  
        if(vec1.contains("nandha"))  
        {  
             System.out.println("nandha is present at the index " +vec1.indexOf("nandha"));  
        }  
        else  
        {  
           System.out.println("nandha is not present in the list");  
        }  
        //elements
        Enumeration<String> enumobject = vec1.elements();  
        System.out.println("Data in enumeration object is: ");  
        while (enumobject.hasMoreElements())   
        {             
            System.out.println("Element: " +enumobject.nextElement());  
        }  
        System.out.println("The last element of a vector is: " +vec1.lastElement());  
        System.out.println("The last element of a vector is: " +vec1.firstElement()); 
        System.out.println("Element at index 1 is = "+vec1.elementAt(1));  
        System.out.println("Element at index 1 is = "+vec1.get(1));  
        vec1.insertElementAt("not", 2);  
        System.out.println(vec1); 
        System.out.println("Is the Vector2 empty? = " +vec1.isEmpty());  
  
        Vector<String> vec2 = new Vector<String>(); 
        //addall
        vec2.addAll(vec1);
        System.out.println("after add all vec3 is "+vec2);
        System.out.println("Does vector contains all list elements?: "+vec2.containsAll(vec1)); 
        vec2.removeAll(vec1);
        //isempty
        if(vec2.isEmpty())
        	
        {
        System.out.println("yes empty");
        vec2.clear();
        }
        
        
  
       
    } 
}